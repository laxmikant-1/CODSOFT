package com.stud;

//Main Class
public class Stud {
public static void main(String[] args) {
   RegistrationSystem system = new RegistrationSystem();

   // Display available courses
   System.out.println("Available Courses:");
   system.displayAvailableCourses();

   // Register a student
   system.registerStudent("S12345", "CS101");

   // Display student schedule
   System.out.println("\nStudent Schedule:");
   system.displayStudentSchedule("S12345");

   // Remove a student from a course
   system.removeStudentFromCourse("S12345", "CS101");

   // Display student schedule after removal
   System.out.println("\nStudent Schedule after removal:");
   system.displayStudentSchedule("S12345");
}
}