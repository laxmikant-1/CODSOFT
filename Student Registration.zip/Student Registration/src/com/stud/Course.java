package com.stud;

import java.util.*;

//Course Class
class Course {
 private String courseCode;
 private String title;
 private String description;
 private int capacity;
 private String schedule;
 private int enrolledStudents;

 public Course(String courseCode, String title, String description, int capacity, String schedule) {
     this.courseCode = courseCode;
     this.title = title;
     this.description = description;
     this.capacity = capacity;
     this.schedule = schedule;
     this.enrolledStudents = 0;
 }

 public String getCourseCode() {
     return courseCode;
 }

 public String getTitle() {
     return title;
 }

 public String getDescription() {
     return description;
 }

 public int getCapacity() {
     return capacity;
 }

 public String getSchedule() {
     return schedule;
 }

 public int getEnrolledStudents() {
     return enrolledStudents;
 }

 public boolean isFull() {
     return enrolledStudents >= capacity;
 }

 public void enrollStudent() {
     if (!isFull()) {
         enrolledStudents++;
     }
 }

 public void removeStudent() {
     if (enrolledStudents > 0) {
         enrolledStudents--;
     }
 }

 @Override
 public String toString() {
     return courseCode + " - " + title + " (" + schedule + ") - Available Slots: " + (capacity - enrolledStudents);
 }
}

//Student Class
class Student {
 private String studentID;
 private String name;
 private List<String> registeredCourses;

 public Student(String studentID, String name) {
     this.studentID = studentID;
     this.name = name;
     this.registeredCourses = new ArrayList<>();
 }

 public String getStudentID() {
     return studentID;
 }

 public String getName() {
     return name;
 }

 public List<String> getRegisteredCourses() {
     return registeredCourses;
 }

 public void registerCourse(String courseCode) {
     if (!registeredCourses.contains(courseCode)) {
         registeredCourses.add(courseCode);
     }
 }

 public void removeCourse(String courseCode) {
     registeredCourses.remove(courseCode);
 }
}

//Course Database
class CourseDatabase {
 private Map<String, Course> courses;

 public CourseDatabase() {
     courses = new HashMap<>();
     // Add sample courses
     courses.put("CS101", new Course("CS101", "Introduction to Computer Science", "Fundamentals of programming", 30, "MWF 9:00 AM"));
     courses.put("MATH201", new Course("MATH201", "Calculus I", "Differential and integral calculus", 25, "TTH 1:00 PM"));
     courses.put("JAVA203", new Course("JAVA203", "Full Stack In Java", "Hands On Programming", 35, "TTH 3:00 PM"));
     courses.put("MYSQL204", new Course("MYSQL204", "Learn Mysql", "Fundamental Knoweledage of Mysql", 30, "MWF 11:00 AM"));
     // Add more courses as needed
 }

 public List<Course> getCourses() {
     return new ArrayList<>(courses.values());
 }

 public Course getCourse(String courseCode) {
     return courses.get(courseCode);
 }
}

//Student Database
class StudentDatabase {
 private Map<String, Student> students;

 public StudentDatabase() {
     students = new HashMap<>();
     // Add sample students
     students.put("S12345", new Student("S12345", "Ram Jadhav"));
     students.put("S67890", new Student("S67890", "Aniket More"));
     students.put("S12345", new Student("S45375", "Ashok kale"));
     students.put("S67890", new Student("S25485", "Ganesh kamthe"));
     // Add more students as needed
 }

 public List<Student> getStudents() {
     return new ArrayList<>(students.values());
 }

 public Student getStudent(String studentID) {
     return students.get(studentID);
 }

 public void addStudent(Student student) {
     students.put(student.getStudentID(), student);
 }
}

//Registration System
class RegistrationSystem {
 private CourseDatabase courseDB;
 private StudentDatabase studentDB;

 public RegistrationSystem() {
     courseDB = new CourseDatabase();
     studentDB = new StudentDatabase();
 }

 public void registerStudent(String studentID, String courseCode) {
     Student student = studentDB.getStudent(studentID);
     Course course = courseDB.getCourse(courseCode);

     if (student != null && course != null && !course.isFull()) {
         student.registerCourse(courseCode);
         course.enrollStudent();
     } else {
         System.out.println("Registration failed. Invalid student ID, course code, or course is full.");
     }
 }

 public void removeStudentFromCourse(String studentID, String courseCode) {
     Student student = studentDB.getStudent(studentID);
     Course course = courseDB.getCourse(courseCode);

     if (student != null && course != null && student.getRegisteredCourses().contains(courseCode)) {
         student.removeCourse(courseCode);
         course.removeStudent();
     } else {
         System.out.println("Removal failed. Invalid student ID, course code, or student not registered for the course.");
     }
 }

 public void displayAvailableCourses() {
     List<Course> courses = courseDB.getCourses();
     for (Course course : courses) {
         System.out.println(course);
     }
 }

 public void displayStudentSchedule(String studentID) {
     Student student = studentDB.getStudent(studentID);
     if (student != null) {
         System.out.println("Student: " + student.getName());
         System.out.println("Registered Courses:");
         for (String courseCode : student.getRegisteredCourses()) {
             System.out.println(courseDB.getCourse(courseCode).getTitle());
         }
     } else {
         System.out.println("Student not found.");
     }
 }
}


