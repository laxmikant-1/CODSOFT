package com.quiz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class QuizApplication extends JFrame implements ActionListener {

    private JLabel questionLabel;
    private JRadioButton[] options;
    private ButtonGroup optionGroup;
    private JButton nextButton;
    private JLabel timerLabel;
    private int currentQuestionIndex;
    private int score;
    private List<Question> questions;
    private Timer quizTimer;
    private int timeRemaining;

    public QuizApplication() {
        setTitle("Quiz Application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(8, 1));

        questionLabel = new JLabel();
        add(questionLabel);

        options = new JRadioButton[4];
        optionGroup = new ButtonGroup();
        for (int i = 0; i < options.length; i++) {
            options[i] = new JRadioButton();
            optionGroup.add(options[i]);
            add(options[i]);
        }

        nextButton = new JButton("Next");
        nextButton.addActionListener(this);
        add(nextButton);

        timerLabel = new JLabel("Time Remaining: ");
        add(timerLabel);

        // Initialize questions
        questions = new ArrayList<>();
        questions.add(new Question("What is the capital of France?", "Paris", "London", "Berlin", "Madrid", "Paris"));
        questions.add(new Question("Who painted the Mona Lisa?", "Leonardo da Vinci", "Michelangelo", "Raphael", "Donatello", "Leonardo da Vinci"));
        questions.add(new Question("What is the largest planet in our solar system?", "Jupiter", "Saturn", "Earth", "Mars", "Jupiter"));
        // Add more questions here

        // Start the quiz
        startQuiz();
        pack();
        setVisible(true);
    }

    private void startQuiz() {
        currentQuestionIndex = 0;
        score = 0;
        loadQuestion();
        startTimer();
    }

    private void loadQuestion() {
        Question currentQuestion = questions.get(currentQuestionIndex);
        questionLabel.setText(currentQuestion.getQuestion());
        options[0].setText(currentQuestion.getOption1());
        options[1].setText(currentQuestion.getOption2());
        options[2].setText(currentQuestion.getOption3());
        options[3].setText(currentQuestion.getOption4());
        optionGroup.clearSelection();
    }

    private void startTimer() {
        timeRemaining = 30; // 30 seconds per question
        timerLabel.setText("Time Remaining: " + timeRemaining);
        quizTimer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                timeRemaining--;
                timerLabel.setText("Time Remaining: " + timeRemaining);
                if (timeRemaining == 0) {
                    quizTimer.stop();
                    nextQuestion(); // Move to the next question even if the answer is not selected
                }
            }
        });
        quizTimer.start();
    }

    private void nextQuestion() {
        quizTimer.stop();
        if (isCorrectAnswer()) {
            score++;
        }
        currentQuestionIndex++;
        if (currentQuestionIndex < questions.size()) {
            loadQuestion();
            startTimer();
        } else {
            showResults();
        }
    }

    private boolean isCorrectAnswer() {
        String selectedOption = getSelectedOption();
        Question currentQuestion = questions.get(currentQuestionIndex);
        return selectedOption != null && selectedOption.equals(currentQuestion.getCorrectAnswer());
    }

    private String getSelectedOption() {
        for (int i = 0; i < options.length; i++) {
            if (options[i].isSelected()) {
                return options[i].getText();
            }
        }
        return null;
    }

    private void showResults() {
        quizTimer.stop();
        String message = "Quiz Completed!\n" +
                "Your Score: " + score + "/" + questions.size();
        JOptionPane.showMessageDialog(this, message);
        dispose(); // Close the quiz window
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == nextButton) {
            nextQuestion();
        }
    }

    public static void main(String[] args) {
        new QuizApplication();
    }
}

class Question {
    private String question;
    private String option1;
    private String option2;
    private String option3;
    private String option4;
    private String correctAnswer;

    public Question(String question, String option1, String option2, String option3, String option4, String correctAnswer) {
        this.question = question;
        this.option1 = option1;
        this.option2 = option2;
        this.option3 = option3;
        this.option4 = option4;
        this.correctAnswer = correctAnswer;
    }

    public String getQuestion() {
        return question;
    }

    public String getOption1() {
        return option1;
    }

    public String getOption2() {
        return option2;
    }

    public String getOption3() {
        return option3;
    }

    public String getOption4() {
        return option4;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }
}
